OC.L10N.register(
    "activity",
    {
    "Activity" : "Gweithred",
    "No activity yet" : "Dim gweithred eto",
    "Home" : "Cartref",
    "Today" : "Heddiw",
    "Yesterday" : "Ddoe",
    "Mail" : "E-bost",
    "Settings" : "Gosodiadau",
    "Files" : "Ffeiliau"
},
"nplurals=4; plural=(n==1) ? 0 : (n==2) ? 1 : (n != 8 && n != 11) ? 2 : 3;");
