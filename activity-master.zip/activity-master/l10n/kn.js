OC.L10N.register(
    "activity",
    {
    "Home" : "﻿ಮುಖಪುಟ",
    "Today" : "Today",
    "Mail" : "ಅಂಚೆ",
    "Settings" : "ಆಯ್ಕೆ",
    "Files" : "ಕಡತಗಳು"
},
"nplurals=2; plural=(n > 1);");
