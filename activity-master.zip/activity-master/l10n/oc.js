OC.L10N.register(
    "activity",
    {
    "Home" : "Domicili",
    "Today" : "Uèi",
    "Yesterday" : "Ièr",
    "Mail" : "Mail",
    "Settings" : "Paramètres",
    "Files" : "Fichièrs"
},
"nplurals=2; plural=(n > 1);");
