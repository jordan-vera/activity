OC.L10N.register(
    "activity",
    {
    "Home" : "அகம்",
    "Today" : "இன்று",
    "Settings" : "அமைப்புகள்",
    "Files" : "கோப்புகள்"
},
"nplurals=2; plural=(n != 1);");
