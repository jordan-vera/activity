OC.L10N.register(
    "activity",
    {
    "Home" : "ئۆي",
    "Today" : "بۈگۈن",
    "Settings" : "تەڭشەكلەر",
    "Files" : "ھۆججەتلەر"
},
"nplurals=1; plural=0;");
