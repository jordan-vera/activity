OC.L10N.register(
    "activity",
    {
    "Copied!" : "Nusxa olindi!",
    "Not supported!" : "Qo'llab-quvvatlanmaydi!",
    "Press ⌘-C to copy." : "Ko'chirib olish uchun ⌘-C tugmasini bosing.",
    "Press Ctrl-C to copy." : "Nusxalash uchun Ctrl-C tugmalarini bosing.",
    "Mail" : "Pochta",
    "Settings" : "Sozlamalar",
    "Files" : "Fayllar"
},
"nplurals=1; plural=0;");
